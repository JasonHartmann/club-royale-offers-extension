(function() {
    console.debug('Club Royale GOBO Indicator extension loaded on:', window.location.href);

    // Global App object to coordinate modules
    window.App = {
        DOMUtils,
        Styles,
        ButtonManager,
        ErrorHandler,
        Spinner,
        ApiClient,
        Modal,
        TableBuilder,
        AccordionBuilder,
        SortUtils,
        TableRenderer,
        Utils,
        OfferCodeLookup,
        Filtering,
        Favorites: window.Favorites, // ensure reference via window
        ProfileCache: [],
        init() {
            this.DOMUtils.waitForDom();
        }
    };

    // Start the application
    App.init();
})();